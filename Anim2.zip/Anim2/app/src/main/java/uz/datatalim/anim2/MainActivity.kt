package uz.datatalim.anim2

import android.content.DialogInterface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initViews()
    }

    private fun initViews() {
        val bSimDialog=findViewById<Button>(R.id.b_SimpleDialog)
        val bCusDialog=findViewById<Button>(R.id.b_CustomDialog)

        bSimDialog.setOnClickListener {
            val dialog=AlertDialog.Builder(this)
            dialog.setIcon(R.drawable.ic_android)
            dialog.setMessage("bu yerda sizning reklamangiz bo'lishi mumkin edi")
            dialog.setTitle("Bu sizning reklamangiz")
            dialog.setCancelable(false)
            dialog.setPositiveButton("yes",object :DialogInterface.OnClickListener{
                override fun onClick(p0: DialogInterface?, p1: Int) {
                    Toast.makeText(this@MainActivity,"yes tugmasi bosildi",Toast.LENGTH_SHORT).show()
                }

            })
            dialog.setNegativeButton("no",object :DialogInterface.OnClickListener{
                override fun onClick(p0: DialogInterface?, p1: Int) {
                    Toast.makeText(this@MainActivity,"no tugmasi bosuldi",Toast.LENGTH_SHORT).show()
                }

            })
            dialog.show()
        }
    }
}